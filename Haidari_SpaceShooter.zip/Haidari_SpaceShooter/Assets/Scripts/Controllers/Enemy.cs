﻿using UnityEngine;
using System.Collections;
using Codice.Client.BaseCommands.CheckIn.Progress;

public class Enemy : MonoBehaviour
{

}
